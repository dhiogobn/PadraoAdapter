package atividade1;

public class GuildWars {
	private Classes classe;
	private String nickName;
	
	
	public GuildWars() {
	}

	public GuildWars(Classes classe, String nickName) {
		this.classe = classe;
		this.nickName = nickName;
	}

	public Classes getClasse() {
		return classe;
	}

	public String getNickName() {
		return nickName;
	}
	
	public String criarPersonagem() {
		String personagem = "";
		if(Classes.BERSEKER == this.classe) {
			personagem = "parabens voc� criou um berserker";
		}else if(Classes.ELEMENTALIST == this.classe) {
			personagem = "parabens voc� criou um elementalist";
		}else if(Classes.GUARDIAN == this.classe) {
			personagem = "parabens voc� criou um guardian";
		}else if(Classes.HUNTER == this.classe) {
			personagem = "parabens voc� criou um hunter";
		}else if(Classes.MESMER == this.classe) {
			personagem = "parabens voc� criou um mesmer";
		}else if(Classes.NECROMANCER == this.classe) {
			personagem = "parabens voc� criou um necromancer";
		}else if(Classes.THIEF == this.classe) {
			personagem = "parabens voc� criou um thief";
		}
		return personagem;
	}
	
	public String getTipoArmamento(){
		String arma= "";
		if(this.classe == Classes.BERSEKER) {
			arma= Armamento.LONG_SWORD.toString();
		}else if(this.classe == Classes.ELEMENTALIST || this.classe == Classes.NECROMANCER || this.classe == Classes.MESMER) {
			arma= Armamento.SCEPTER.toString();
		}else if(this.classe == Classes.GUARDIAN){
			arma= Armamento.SWORD+" e "+ Armamento.SHIELD ;
		}else if(this.classe == Classes.HUNTER){
			arma= Armamento.lONG_BOW+" ou "+ Armamento.SHORT_BOW;
		}else if(this.classe == Classes.THIEF){
			arma= Armamento.DAGGER.toString();
		}
		return arma;
	}
	
	public String removerPersonagem() {
		return "seu personagem "+this.nickName+ " que pertence a classe "+this.classe+" foi removido";
	}
	
	
	
	
	

}
