package atividade1;

public enum Classes {
	GUARDIAN, HUNTER, NECROMANCER, THIEF, MESMER, BERSEKER, ELEMENTALIST
}
