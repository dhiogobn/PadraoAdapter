package atividade1;

public enum Armamento {
	DAGGER, SHORT_BOW, lONG_BOW, SCEPTER, SWORD,LONG_SWORD, SHIELD

}
