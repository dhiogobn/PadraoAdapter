package atividade1;

import static org.junit.Assert.*;
import org.junit.Test;

public class GuildWarsTest {
	@Test
	public void testCriarPersonagem() {
		GuildWars thief = new GuildWars(Classes.THIEF, "bandeirao");
		assertEquals("parabens voc� criou um thief", thief.criarPersonagem());
		
	}
	@Test
	public void testTipoArmamento() {
		GuildWars thief = new GuildWars(Classes.THIEF, "bandeirao");
		assertEquals("DAGGER", thief.getTipoArmamento());
		
	}
	@Test
	public void testExcluirPersonagem() {
		GuildWars thief = new GuildWars(Classes.THIEF, "bandeirao");
		assertEquals("seu personagem bandeirao que pertence a classe THIEF foi removido", thief.removerPersonagem());

		
	}

}
